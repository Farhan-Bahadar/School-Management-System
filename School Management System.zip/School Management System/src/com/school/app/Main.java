package com.school.app;

import com.school.database.DatabaseConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Test database connection on startup
        DatabaseConnection.getInstance().getConnection();

        URL fxmlUrl = getClass().getResource("/resources/fxml/Login.fxml");
        if (fxmlUrl == null) {
            System.err.println("Cannot find Login.fxml. Ensure resources folder is set as Resources Root in IntelliJ.");
            System.exit(1);
        }

        Parent root = FXMLLoader.load(fxmlUrl);
        Scene scene = new Scene(root, 800, 600);
        
        primaryStage.setTitle("School ERP - Login");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        // Close database connection when app exits
        DatabaseConnection.getInstance().closeConnection();
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
