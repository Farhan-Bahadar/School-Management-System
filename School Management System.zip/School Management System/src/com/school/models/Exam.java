package com.school.models;

import java.time.LocalDate;

public class Exam {
    private int id;
    private String examName;
    private LocalDate startDate;
    private LocalDate endDate;

    public Exam() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getExamName() { return examName; }
    public void setExamName(String examName) { this.examName = examName; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
}
