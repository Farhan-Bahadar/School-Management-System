package com.school.models;

import java.time.LocalDate;

public class Attendance {
    private long id;
    private int studentId;
    private int classId;
    private LocalDate date;
    private String status;
    private String remarks;

    // Transient fields for UI display (populated via JOIN)
    private String studentName;
    private String className;
    private String admissionNumber;

    public Attendance() {
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getClassId() { return classId; }
    public void setClassId(int classId) { this.classId = classId; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    public String getAdmissionNumber() { return admissionNumber; }
    public void setAdmissionNumber(String admissionNumber) { this.admissionNumber = admissionNumber; }
}
