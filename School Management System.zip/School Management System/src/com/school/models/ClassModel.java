package com.school.models;

public class ClassModel {
    private int id;
    private String className;
    private String section;
    private String roomNumber;
    private Integer teacherId;

    // Additional fields for displaying in UI (populated via JOIN in DAO)
    private String teacherName;

    public ClassModel() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    public String getSection() { return section; }
    public void setSection(String section) { this.section = section; }

    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }

    public Integer getTeacherId() { return teacherId; }
    public void setTeacherId(Integer teacherId) { this.teacherId = teacherId; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    // Helper to return full class name (e.g., "Grade 10 - A")
    public String getFullClassName() {
        return className + " - " + section;
    }
}
