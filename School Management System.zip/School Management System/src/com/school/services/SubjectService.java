package com.school.services;

import com.school.dao.SubjectDAO;
import com.school.models.Subject;

import java.util.List;

public class SubjectService {

    private final SubjectDAO subjectDAO;

    public SubjectService() {
        this.subjectDAO = new SubjectDAO();
    }

    public List<Subject> getAllSubjects() {
        return subjectDAO.getAllSubjects();
    }

    public boolean addSubject(Subject subject) {
        if (subject.getSubjectCode() == null || subject.getSubjectCode().trim().isEmpty()) {
            throw new IllegalArgumentException("Subject code is required.");
        }
        if (subject.getSubjectName() == null || subject.getSubjectName().trim().isEmpty()) {
            throw new IllegalArgumentException("Subject name is required.");
        }
        
        return subjectDAO.addSubject(subject);
    }
    
    public boolean updateSubject(Subject subject) {
        return subjectDAO.updateSubject(subject);
    }

    public List<Subject> searchSubjects(String keyword) {
        return subjectDAO.searchSubjects(keyword);
    }

    public boolean removeSubject(int subjectId) {
        return subjectDAO.deleteSubject(subjectId);
    }
}
