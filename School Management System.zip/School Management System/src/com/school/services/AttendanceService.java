package com.school.services;

import com.school.dao.AttendanceDAO;
import com.school.models.Attendance;

import java.time.LocalDate;
import java.util.List;

public class AttendanceService {

    private final AttendanceDAO attendanceDAO;

    public AttendanceService() {
        this.attendanceDAO = new AttendanceDAO();
    }

    public List<Attendance> getAllAttendance() {
        return attendanceDAO.getAllAttendance();
    }

    public boolean markAttendance(Attendance att) {
        if (att.getStudentId() <= 0) {
            throw new IllegalArgumentException("Valid Student ID is required.");
        }
        if (att.getClassId() <= 0) {
            throw new IllegalArgumentException("Valid Class ID is required.");
        }
        if (att.getDate() == null) {
            throw new IllegalArgumentException("Date is required.");
        }
        if (att.getDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Cannot mark attendance for a future date.");
        }
        if (att.getStatus() == null || att.getStatus().trim().isEmpty()) {
            throw new IllegalArgumentException("Attendance status is required.");
        }
        
        return attendanceDAO.addAttendance(att);
    }

    public List<Attendance> getAttendanceByDateAndClass(LocalDate date, int classId) {
        return attendanceDAO.getAttendanceByDateAndClass(date, classId);
    }
}
