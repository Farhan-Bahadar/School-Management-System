package com.school.services;

import com.school.dao.StudentDAO;
import com.school.models.Student;

import java.util.List;

public class StudentService {

    private final StudentDAO studentDAO;

    public StudentService() {
        this.studentDAO = new StudentDAO();
    }

    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    public boolean addStudent(Student student, Integer classId) {
        // Basic validation
        if (student.getAdmissionNumber() == null || student.getAdmissionNumber().trim().isEmpty()) {
            throw new IllegalArgumentException("Admission number is required.");
        }
        
        int studentId = studentDAO.addStudent(student);
        if (studentId > 0) {
            if (classId != null) {
                // Default academic year, could be made dynamic
                studentDAO.enrollStudent(studentId, classId, "2023-2024");
            }
            return true;
        }
        return false;
    }

    public boolean updateStudent(Student student) {
        return studentDAO.updateStudent(student);
    }

    public boolean deleteStudent(int studentId) {
        return studentDAO.deleteStudent(studentId);
    }

    public List<Student> searchStudents(String keyword) {
        return studentDAO.searchStudents(keyword);
    }

    public List<Student> getStudentsByClass(int classId) {
        return studentDAO.getStudentsByClass(classId);
    }
}
