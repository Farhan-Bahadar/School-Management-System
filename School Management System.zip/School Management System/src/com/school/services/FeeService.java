package com.school.services;

import com.school.dao.FeeDAO;
import com.school.models.Fee;

import java.util.List;

public class FeeService {

    private final FeeDAO feeDAO;

    public FeeService() {
        this.feeDAO = new FeeDAO();
    }

    public List<Fee> getAllFees() {
        return feeDAO.getAllFees();
    }

    public boolean createFeeRecord(Fee fee) {
        if (fee.getAmount() <= 0) {
            throw new IllegalArgumentException("Fee amount must be greater than zero.");
        }
        if (fee.getStudentId() <= 0) {
            throw new IllegalArgumentException("Valid Student ID is required.");
        }
        
        return feeDAO.addFee(fee);
    }
    
    public boolean updateFee(Fee fee) {
        return feeDAO.updateFee(fee);
    }

    public List<Fee> searchFees(String keyword) {
        return feeDAO.searchFees(keyword);
    }

    public boolean removeFee(int feeId) {
        return feeDAO.deleteFee(feeId);
    }
}
