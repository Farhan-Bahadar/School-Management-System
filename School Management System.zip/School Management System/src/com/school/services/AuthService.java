package com.school.services;

import com.school.dao.UserDAO;
import com.school.models.User;
import com.school.utils.PasswordUtils;
import com.school.utils.SessionManager;

public class AuthService {
    
    private final UserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    /**
     * Authenticates a user by checking the username and hashing the provided password.
     * 
     * @param username The username
     * @param plainTextPassword The raw password
     * @return true if authentication is successful, false otherwise
     */
    public boolean login(String username, String plainTextPassword) {
        User user = userDAO.getUserByUsername(username);
        
        if (user != null) {
            // Verify password
            if (PasswordUtils.verifyPassword(plainTextPassword, user.getPasswordHash())) {
                // Login successful
                SessionManager.getInstance().setCurrentUser(user);
                userDAO.updateLastLogin(user.getId());
                return true;
            }
        }
        return false;
    }

    public boolean updatePassword(int userId, String hashedPass) {
        return userDAO.updatePassword(userId, hashedPass);
    }

    public void logout() {
        SessionManager.getInstance().logout();
    }
}
