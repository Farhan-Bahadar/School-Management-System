package com.school.services;

import com.school.dao.ClassDAO;
import com.school.models.ClassModel;

import java.util.List;

public class ClassService {

    private final ClassDAO classDAO;

    public ClassService() {
        this.classDAO = new ClassDAO();
    }

    public List<ClassModel> getAllClasses() {
        return classDAO.getAllClasses();
    }

    public boolean addClass(ClassModel classModel) {
        if (classModel.getClassName() == null || classModel.getClassName().trim().isEmpty()) {
            throw new IllegalArgumentException("Class name is required.");
        }
        if (classModel.getSection() == null || classModel.getSection().trim().isEmpty()) {
            throw new IllegalArgumentException("Section is required.");
        }
        
        return classDAO.addClass(classModel);
    }
    
    public boolean updateClass(ClassModel classModel) {
        return classDAO.updateClass(classModel);
    }

    public List<ClassModel> searchClasses(String keyword) {
        return classDAO.searchClasses(keyword);
    }

    public boolean removeClass(int classId) {
        return classDAO.deleteClass(classId);
    }
}
