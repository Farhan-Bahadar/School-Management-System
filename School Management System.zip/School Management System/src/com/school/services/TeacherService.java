package com.school.services;

import com.school.dao.TeacherDAO;
import com.school.models.Teacher;

import java.util.List;

public class TeacherService {

    private final TeacherDAO teacherDAO;

    public TeacherService() {
        this.teacherDAO = new TeacherDAO();
    }

    public List<Teacher> getAllTeachers() {
        return teacherDAO.getAllTeachers();
    }

    public boolean registerTeacher(Teacher teacher) {
        if (teacher.getEmployeeId() == null || teacher.getEmployeeId().trim().isEmpty()) {
            throw new IllegalArgumentException("Employee ID is required.");
        }
        if (teacher.getEmail() == null || teacher.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required.");
        }
        
        return teacherDAO.addTeacher(teacher);
    }
    
    public boolean updateTeacher(Teacher teacher) {
        return teacherDAO.updateTeacher(teacher);
    }

    public List<Teacher> searchTeachers(String keyword) {
        return teacherDAO.searchTeachers(keyword);
    }

    public boolean removeTeacher(int teacherId) {
        return teacherDAO.deleteTeacher(teacherId);
    }
}
