package com.school.services;

import com.school.dao.LibraryDAO;
import com.school.models.Book;

import java.util.List;

public class LibraryService {

    private final LibraryDAO libraryDAO;

    public LibraryService() {
        this.libraryDAO = new LibraryDAO();
    }

    public List<Book> getAllBooks() {
        return libraryDAO.getAllBooks();
    }

    public boolean createBook(Book book) {
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("Book title is required.");
        }
        if (book.getAuthor() == null || book.getAuthor().trim().isEmpty()) {
            throw new IllegalArgumentException("Author name is required.");
        }
        if (book.getAddedDate() == null) {
            throw new IllegalArgumentException("Added date is required.");
        }
        
        return libraryDAO.addBook(book);
    }
    
    public boolean updateBook(Book book) {
        return libraryDAO.updateBook(book);
    }

    public List<Book> searchBooks(String keyword) {
        return libraryDAO.searchBooks(keyword);
    }

    public boolean removeBook(int bookId) {
        return libraryDAO.deleteBook(bookId);
    }
}
