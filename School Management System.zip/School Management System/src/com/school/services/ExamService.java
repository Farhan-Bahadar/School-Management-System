package com.school.services;

import com.school.dao.ExamDAO;
import com.school.models.Exam;

import java.util.List;

public class ExamService {

    private final ExamDAO examDAO;

    public ExamService() {
        this.examDAO = new ExamDAO();
    }

    public List<Exam> getAllExams() {
        return examDAO.getAllExams();
    }

    public boolean addExam(Exam exam) {
        if (exam.getExamName() == null || exam.getExamName().trim().isEmpty()) {
            throw new IllegalArgumentException("Exam name is required.");
        }
        if (exam.getStartDate() == null || exam.getEndDate() == null) {
            throw new IllegalArgumentException("Start date and end date are required.");
        }
        if (exam.getEndDate().isBefore(exam.getStartDate())) {
            throw new IllegalArgumentException("End date cannot be before start date.");
        }
        
        return examDAO.addExam(exam);
    }
    
    public boolean updateExam(Exam exam) {
        return examDAO.updateExam(exam);
    }

    public List<Exam> searchExams(String keyword) {
        return examDAO.searchExams(keyword);
    }

    public boolean removeExam(int examId) {
        return examDAO.deleteExam(examId);
    }
}
