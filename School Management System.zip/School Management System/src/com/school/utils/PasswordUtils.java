package com.school.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Utility class for handling password hashing securely.
 */
public class PasswordUtils {

    /**
     * Hashes a plain text password using SHA-256.
     * In a real enterprise system, bcrypt or Argon2 should be used.
     * For pure Java SE without external dependencies, SHA-256 is used here.
     * 
     * @param plainTextPassword The plain text password
     * @return The hashed password
     */
    public static String hashPassword(String plainTextPassword) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(plainTextPassword.getBytes());
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    /**
     * Verifies a plain text password against a hashed password.
     * 
     * @param plainTextPassword The plain text password entered by the user
     * @param hashedPassword The stored hashed password from the database
     * @return true if they match, false otherwise
     */
    public static boolean verifyPassword(String plainTextPassword, String hashedPassword) {
        String newHash = hashPassword(plainTextPassword);
        return newHash.equals(hashedPassword);
    }
}
