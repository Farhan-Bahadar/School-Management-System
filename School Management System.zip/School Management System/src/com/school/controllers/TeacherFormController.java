package com.school.controllers;

import com.school.models.Teacher;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class TeacherFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtEmployeeId;
    @FXML private TextField txtFirstName;
    @FXML private TextField txtLastName;
    @FXML private ComboBox<String> comboGender;
    @FXML private DatePicker dateBirth;
    @FXML private TextField txtQualification;
    @FXML private DatePicker dateHire;
    @FXML private ComboBox<String> comboStatus;
    @FXML private TextField txtContact;
    @FXML private TextField txtEmail;
    @FXML private TextArea txtAddress;
    @FXML private Button btnSave;

    private Teacher teacher;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        comboGender.setItems(FXCollections.observableArrayList("MALE", "FEMALE", "OTHER"));
        comboStatus.setItems(FXCollections.observableArrayList("ACTIVE", "ON_LEAVE", "RESIGNED", "RETIRED"));
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
        if (teacher != null) {
            lblTitle.setText("Edit Teacher");
            txtEmployeeId.setText(teacher.getEmployeeId());
            txtFirstName.setText(teacher.getFirstName());
            txtLastName.setText(teacher.getLastName());
            comboGender.setValue(teacher.getGender());
            dateBirth.setValue(teacher.getDateOfBirth());
            txtQualification.setText(teacher.getQualification());
            dateHire.setValue(teacher.getHireDate());
            comboStatus.setValue(teacher.getStatus());
            txtContact.setText(teacher.getContactNumber());
            txtEmail.setText(teacher.getEmail());
            txtAddress.setText(teacher.getAddress());
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (teacher == null) {
                teacher = new Teacher();
            }

            teacher.setEmployeeId(txtEmployeeId.getText());
            teacher.setFirstName(txtFirstName.getText());
            teacher.setLastName(txtLastName.getText());
            teacher.setGender(comboGender.getValue());
            teacher.setDateOfBirth(dateBirth.getValue());
            teacher.setQualification(txtQualification.getText());
            teacher.setHireDate(dateHire.getValue());
            teacher.setStatus(comboStatus.getValue());
            teacher.setContactNumber(txtContact.getText());
            teacher.setEmail(txtEmail.getText());
            teacher.setAddress(txtAddress.getText());

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtEmployeeId.getText() == null || txtEmployeeId.getText().isEmpty()) {
            errorMessage += "Employee ID is required!\n";
        }
        if (txtFirstName.getText() == null || txtFirstName.getText().isEmpty()) {
            errorMessage += "First name is required!\n";
        }
        if (txtLastName.getText() == null || txtLastName.getText().isEmpty()) {
            errorMessage += "Last name is required!\n";
        }
        if (comboGender.getValue() == null) {
            errorMessage += "Gender is required!\n";
        }
        if (dateBirth.getValue() == null) {
            errorMessage += "Date of birth is required!\n";
        }
        if (txtQualification.getText() == null || txtQualification.getText().isEmpty()) {
            errorMessage += "Qualification is required!\n";
        }
        if (dateHire.getValue() == null) {
            errorMessage += "Hire date is required!\n";
        }
        if (txtContact.getText() == null || txtContact.getText().isEmpty()) {
            errorMessage += "Contact number is required!\n";
        }
        if (txtEmail.getText() == null || txtEmail.getText().isEmpty()) {
            errorMessage += "Email is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
