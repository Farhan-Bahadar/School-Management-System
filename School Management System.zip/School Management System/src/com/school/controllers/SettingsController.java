package com.school.controllers;

import com.school.models.User;
import com.school.services.AuthService;
import com.school.utils.PasswordUtils;
import com.school.utils.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

import java.net.URL;
import java.util.ResourceBundle;

public class SettingsController implements Initializable {

    @FXML private Label lblUsername;
    @FXML private Label lblRole;
    @FXML private PasswordField txtNewPassword;
    @FXML private PasswordField txtConfirmPassword;

    private final AuthService authService;

    public SettingsController() {
        this.authService = new AuthService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            lblUsername.setText(currentUser.getUsername());
            lblRole.setText(currentUser.getRole());
        }
    }

    @FXML
    private void handleSavePassword(ActionEvent event) {
        String newPass = txtNewPassword.getText();
        String confirmPass = txtConfirmPassword.getText();

        if (newPass == null || newPass.trim().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Password cannot be empty.");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match.");
            return;
        }

        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser != null) {
            String hashedPass = PasswordUtils.hashPassword(newPass);
            if (authService.updatePassword(currentUser.getId(), hashedPass)) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Password updated successfully.");
                txtNewPassword.clear();
                txtConfirmPassword.clear();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update password.");
            }
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
