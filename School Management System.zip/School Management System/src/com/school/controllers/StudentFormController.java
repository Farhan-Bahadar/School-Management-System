package com.school.controllers;

import com.school.models.ClassModel;
import com.school.models.Student;
import com.school.services.ClassService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class StudentFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtAdmission;
    @FXML private TextField txtFirstName;
    @FXML private TextField txtLastName;
    @FXML private ComboBox<String> comboGender;
    @FXML private DatePicker dateBirth;
    @FXML private TextField txtBlood;
    @FXML private ComboBox<String> comboStatus;
    @FXML private ComboBox<ClassModel> comboClass;
    @FXML private TextField txtParentName;
    @FXML private TextField txtParentContact;
    @FXML private TextField txtParentEmail;
    @FXML private TextArea txtAddress;
    @FXML private Button btnSave;

    private Student student;
    private boolean saveClicked = false;
    private final ClassService classService;

    public StudentFormController() {
        this.classService = new ClassService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        comboGender.setItems(FXCollections.observableArrayList("MALE", "FEMALE", "OTHER"));
        comboStatus.setItems(FXCollections.observableArrayList("ACTIVE", "INACTIVE", "GRADUATED", "TRANSFERRED"));
        comboStatus.setValue("ACTIVE");
        
        loadClasses();
    }

    private void loadClasses() {
        List<ClassModel> classes = classService.getAllClasses();
        comboClass.setItems(FXCollections.observableArrayList(classes));
        comboClass.setConverter(new StringConverter<ClassModel>() {
            @Override
            public String toString(ClassModel cls) {
                return cls == null ? "Select Class" : cls.getFullClassName();
            }

            @Override
            public ClassModel fromString(String string) {
                return null;
            }
        });
    }

    public void setStudent(Student student) {
        this.student = student;
        if (student != null) {
            lblTitle.setText("Edit Student");
            txtAdmission.setText(student.getAdmissionNumber());
            txtFirstName.setText(student.getFirstName());
            txtLastName.setText(student.getLastName());
            comboGender.setValue(student.getGender());
            dateBirth.setValue(student.getDateOfBirth());
            txtBlood.setText(student.getBloodGroup());
            comboStatus.setValue(student.getStatus());
            txtParentName.setText(student.getParentName());
            txtParentContact.setText(student.getParentContact());
            txtParentEmail.setText(student.getParentEmail());
            txtAddress.setText(student.getAddress());
            
            // Note: Current student class loading is missing in the model/DAO
            // For now, we allow assigning a new class during edit
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Student getStudent() {
        return student;
    }
    
    public Integer getSelectedClassId() {
        ClassModel selected = comboClass.getValue();
        return selected != null ? selected.getId() : null;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (student == null) {
                student = new Student();
                student.setEnrollmentDate(LocalDate.now());
            }

            student.setAdmissionNumber(txtAdmission.getText());
            student.setFirstName(txtFirstName.getText());
            student.setLastName(txtLastName.getText());
            student.setGender(comboGender.getValue());
            student.setDateOfBirth(dateBirth.getValue());
            student.setBloodGroup(txtBlood.getText());
            student.setStatus(comboStatus.getValue());
            student.setParentName(txtParentName.getText());
            student.setParentContact(txtParentContact.getText());
            student.setParentEmail(txtParentEmail.getText());
            student.setAddress(txtAddress.getText());

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtAdmission.getText() == null || txtAdmission.getText().isEmpty()) {
            errorMessage += "Admission number is required!\n";
        }
        if (txtFirstName.getText() == null || txtFirstName.getText().isEmpty()) {
            errorMessage += "First name is required!\n";
        }
        if (txtLastName.getText() == null || txtLastName.getText().isEmpty()) {
            errorMessage += "Last name is required!\n";
        }
        if (comboGender.getValue() == null) {
            errorMessage += "Gender is required!\n";
        }
        if (dateBirth.getValue() == null) {
            errorMessage += "Date of birth is required!\n";
        }
        if (comboClass.getValue() == null && student == null) {
            errorMessage += "Class assignment is required for new students!\n";
        }
        if (txtParentName.getText() == null || txtParentName.getText().isEmpty()) {
            errorMessage += "Parent name is required!\n";
        }
        if (txtParentContact.getText() == null || txtParentContact.getText().isEmpty()) {
            errorMessage += "Parent contact is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
