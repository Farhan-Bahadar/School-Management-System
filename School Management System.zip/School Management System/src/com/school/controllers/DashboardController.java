package com.school.controllers;

import com.school.utils.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML private BorderPane mainPane;
    @FXML private Label lblWelcome;
    
    // Sidebar Buttons
    @FXML private Button btnDashboard;
    @FXML private Button btnStudents;
    @FXML private Button btnTeachers;
    @FXML private Button btnClasses;
    @FXML private Button btnFees;
    @FXML private Button btnAttendance;
    @FXML private Button btnExams;
    @FXML private Button btnSubjects;
    @FXML private Button btnLibrary;
    @FXML private Button btnSettings;

    private static DashboardController instance;

    public static DashboardController getInstance() {
        return instance;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        instance = this;
        System.out.println("[SYSTEM] Rebuilding Dashboard Navigation System...");
        
        if (SessionManager.getInstance().isLoggedIn()) {
            String username = SessionManager.getInstance().getCurrentUser().getUsername();
            lblWelcome.setText("Welcome, " + username);
        }
        
        // Load default view
        showDashboardOverview(null);
    }

    @FXML
    public void showDashboardOverview(ActionEvent event) {
        System.out.println("[CLICK] Dashboard Sidebar Button clicked.");
        setActiveButton(btnDashboard);
        loadModule("/resources/fxml/DashboardOverview.fxml");
    }

    @FXML
    public void showStudentManagement(ActionEvent event) {
        System.out.println("[CLICK] Students Sidebar Button clicked.");
        setActiveButton(btnStudents);
        loadModule("/resources/fxml/StudentManagement.fxml");
    }

    @FXML
    public void showTeacherManagement(ActionEvent event) {
        System.out.println("[CLICK] Teachers Sidebar Button clicked.");
        setActiveButton(btnTeachers);
        loadModule("/resources/fxml/TeacherManagement.fxml");
    }

    @FXML
    public void showClassManagement(ActionEvent event) {
        System.out.println("[CLICK] Classes Sidebar Button clicked.");
        setActiveButton(btnClasses);
        loadModule("/resources/fxml/ClassManagement.fxml");
    }

    @FXML
    public void showFeeManagement(ActionEvent event) {
        System.out.println("[CLICK] Fees Sidebar Button clicked.");
        setActiveButton(btnFees);
        loadModule("/resources/fxml/FeeManagement.fxml");
    }

    @FXML
    public void showAttendanceManagement(ActionEvent event) {
        System.out.println("[CLICK] Attendance Sidebar Button clicked.");
        setActiveButton(btnAttendance);
        loadModule("/resources/fxml/AttendanceManagement.fxml");
    }

    @FXML
    public void showExamManagement(ActionEvent event) {
        System.out.println("[CLICK] Exams Sidebar Button clicked.");
        setActiveButton(btnExams);
        loadModule("/resources/fxml/ExamManagement.fxml");
    }

    @FXML
    public void showSubjectManagement(ActionEvent event) {
        System.out.println("[CLICK] Subjects Sidebar Button clicked.");
        setActiveButton(btnSubjects);
        loadModule("/resources/fxml/SubjectManagement.fxml");
    }

    @FXML
    public void showLibraryManagement(ActionEvent event) {
        System.out.println("[CLICK] Library Sidebar Button clicked.");
        setActiveButton(btnLibrary);
        loadModule("/resources/fxml/LibraryManagement.fxml");
    }

    private void setActiveButton(Button activeBtn) {
        // Reset all buttons
        if (btnDashboard != null) btnDashboard.getStyleClass().remove("sidebar-btn-active");
        if (btnStudents != null) btnStudents.getStyleClass().remove("sidebar-btn-active");
        if (btnTeachers != null) btnTeachers.getStyleClass().remove("sidebar-btn-active");
        if (btnClasses != null) btnClasses.getStyleClass().remove("sidebar-btn-active");
        if (btnFees != null) btnFees.getStyleClass().remove("sidebar-btn-active");
        if (btnAttendance != null) btnAttendance.getStyleClass().remove("sidebar-btn-active");
        if (btnExams != null) btnExams.getStyleClass().remove("sidebar-btn-active");
        if (btnSubjects != null) btnSubjects.getStyleClass().remove("sidebar-btn-active");
        if (btnLibrary != null) btnLibrary.getStyleClass().remove("sidebar-btn-active");
        if (btnSettings != null) btnSettings.getStyleClass().remove("sidebar-btn-active");
        
        // Add active class to selected button
        if (activeBtn != null) {
            activeBtn.getStyleClass().add("sidebar-btn-active");
        }
    }

    @FXML
    public void showSettings(ActionEvent event) {
        System.out.println("[CLICK] Settings Sidebar Button clicked.");
        setActiveButton(btnSettings);
        loadModule("/resources/fxml/Settings.fxml");
    }

    /**
     * Centralized content loader with robust path resolution and error handling.
     */
    private void loadModule(String fxmlPath) {
        try {
            System.out.println("[LOADER] Loading module: " + fxmlPath);
            
            // Try loading as resource
            URL url = getClass().getResource(fxmlPath);
            if (url == null) {
                throw new IOException("FXML file not found: " + fxmlPath);
            }
            
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();
            
            // Programmatic Styling to avoid FXML path resolution issues
            try {
                URL cssUrl = getClass().getResource("/resources/css/style.css");
                if (cssUrl != null) {
                    root.getStyleClass().add("root"); // Ensure variables are available
                    root.getStylesheets().add(cssUrl.toExternalForm());
                }
            } catch (Exception cssEx) {
                System.err.println("[WARN] Could not apply stylesheet programmatically: " + cssEx.getMessage());
            }
            
            // Centralized Center Swapping
            mainPane.setCenter(root);
            System.out.println("[SUCCESS] Module " + fxmlPath + " loaded.");
            
        } catch (Exception e) {
            System.err.println("[CRITICAL ERROR] Failed to load: " + fxmlPath);
            e.printStackTrace();
            showErrorAlert("Module Load Error", "Failed to load " + fxmlPath, e);
        }
    }

    private void showErrorAlert(String title, String content, Exception e) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        String message = content;
        if (e != null && e.getCause() != null) {
            message += "\nCause: " + e.getCause().getMessage();
        } else if (e != null) {
            message += "\nError: " + e.getMessage();
        }
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        System.out.println("[AUTH] Logging out user...");
        SessionManager.getInstance().logout();
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/Login.fxml"));
            Parent root = loader.load();
            
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle("School ERP - Login");
            stage.centerOnScreen();
            
            System.out.println("[AUTH] Redirected to Login screen.");
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to load Login screen.");
            e.printStackTrace();
        }
    }
}
