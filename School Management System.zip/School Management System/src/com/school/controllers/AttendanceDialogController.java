package com.school.controllers;

import com.school.models.Attendance;
import com.school.models.ClassModel;
import com.school.models.Student;
import com.school.services.AttendanceService;
import com.school.services.ClassService;
import com.school.services.StudentService;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class AttendanceDialogController implements Initializable {

    @FXML private ComboBox<ClassModel> comboClass;
    @FXML private DatePicker datePicker;
    @FXML private TableView<Attendance> studentAttendanceTable;
    @FXML private TableColumn<Attendance, String> colAdmission;
    @FXML private TableColumn<Attendance, String> colName;
    @FXML private TableColumn<Attendance, String> colStatus;
    @FXML private Button btnSave;

    private ClassService classService;
    private StudentService studentService;
    private AttendanceService attendanceService;
    private ObservableList<Attendance> attendanceList = FXCollections.observableArrayList();
    private boolean saveClicked = false;

    public AttendanceDialogController() {
        this.classService = new ClassService();
        this.studentService = new StudentService();
        this.attendanceService = new AttendanceService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        datePicker.setValue(LocalDate.now());
        loadClasses();
        setupTable();
    }

    private void loadClasses() {
        List<ClassModel> classes = classService.getAllClasses();
        comboClass.setItems(FXCollections.observableArrayList(classes));
        comboClass.setConverter(new StringConverter<ClassModel>() {
            @Override
            public String toString(ClassModel cls) {
                return cls == null ? "" : cls.getFullClassName();
            }

            @Override
            public ClassModel fromString(String string) {
                return null;
            }
        });
    }

    private void setupTable() {
        colAdmission.setCellValueFactory(new PropertyValueFactory<>("admissionNumber"));
        colName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        
        colStatus.setCellFactory(column -> new TableCell<Attendance, String>() {
            private final ComboBox<String> comboBox = new ComboBox<>(FXCollections.observableArrayList("PRESENT", "ABSENT", "LATE", "HALF_DAY"));

            {
                comboBox.setOnAction(event -> {
                    Attendance attendance = getTableView().getItems().get(getIndex());
                    attendance.setStatus(comboBox.getValue());
                });
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Attendance attendance = getTableView().getItems().get(getIndex());
                    comboBox.setValue(attendance.getStatus());
                    setGraphic(comboBox);
                }
            }
        });
        
        studentAttendanceTable.setItems(attendanceList);
    }

    @FXML
    private void handleClassSelection(ActionEvent event) {
        ClassModel selectedClass = comboClass.getValue();
        if (selectedClass != null) {
            List<Student> students = studentService.getStudentsByClass(selectedClass.getId());
            attendanceList.clear();
            for (Student s : students) {
                Attendance a = new Attendance();
                a.setStudentId(s.getId());
                a.setStudentName(s.getFullName());
                a.setAdmissionNumber(s.getAdmissionNumber());
                a.setClassId(selectedClass.getId());
                a.setDate(datePicker.getValue());
                a.setStatus("PRESENT"); // Default
                attendanceList.add(a);
            }
        }
    }

    @FXML
    private void handleMarkAllPresent(ActionEvent event) {
        for (Attendance a : attendanceList) {
            a.setStatus("PRESENT");
        }
        studentAttendanceTable.refresh();
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (attendanceList.isEmpty()) {
            return;
        }

        boolean success = true;
        for (Attendance a : attendanceList) {
            a.setDate(datePicker.getValue());
            if (!attendanceService.markAttendance(a)) {
                success = false;
            }
        }

        if (success) {
            saveClicked = true;
            closeStage();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to save some attendance records. They might already exist for this date.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }
}
