package com.school.controllers;

import com.school.models.Exam;
import com.school.services.ExamService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ExamController implements Initializable {

    @FXML private TableView<Exam> examTable;
    @FXML private TableColumn<Exam, Integer> colId;
    @FXML private TableColumn<Exam, String> colExamName;
    @FXML private TableColumn<Exam, String> colStartDate;
    @FXML private TableColumn<Exam, String> colEndDate;
    
    @FXML private TextField searchField;

    private final ExamService examService;
    private ObservableList<Exam> examList;

    public ExamController() {
        this.examService = new ExamService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadExams();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colExamName.setCellValueFactory(new PropertyValueFactory<>("examName"));
        colStartDate.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        colEndDate.setCellValueFactory(new PropertyValueFactory<>("endDate"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadExams();
            } else {
                List<Exam> filtered = examService.searchExams(newValue);
                examList = FXCollections.observableArrayList(filtered);
                examTable.setItems(examList);
            }
        });
    }

    @FXML
    private void loadExams() {
        List<Exam> exams = examService.getAllExams();
        examList = FXCollections.observableArrayList(exams);
        examTable.setItems(examList);
    }

    @FXML
    private void handleAddExam(ActionEvent event) {
        showExamForm(null);
    }

    @FXML
    private void handleEditExam(ActionEvent event) {
        Exam selected = examTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showExamForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select an exam to edit.");
        }
    }

    @FXML
    private void handleDeleteExam(ActionEvent event) {
        Exam selected = examTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete exam: " + selected.getExamName() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (examService.removeExam(selected.getId())) {
                    loadExams();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Exam deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete exam.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select an exam to delete.");
        }
    }

    private void showExamForm(Exam exam) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/ExamForm.fxml"));
            Parent root = loader.load();

            ExamFormController controller = loader.getController();
            controller.setExam(exam);

            Stage stage = new Stage();
            stage.setTitle(exam == null ? "Add New Exam" : "Edit Exam");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Exam examData = controller.getExam();
                boolean success;
                if (exam == null) {
                    success = examService.addExam(examData);
                } else {
                    success = examService.updateExam(examData);
                }

                if (success) {
                    loadExams();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Exam saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save exam.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the exam form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
