package com.school.controllers;

import com.school.models.Subject;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class SubjectFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtSubjectCode;
    @FXML private TextField txtSubjectName;
    @FXML private TextArea txtDescription;
    @FXML private Button btnSave;

    private Subject subject;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
        if (subject != null) {
            lblTitle.setText("Edit Subject");
            txtSubjectCode.setText(subject.getSubjectCode());
            txtSubjectName.setText(subject.getSubjectName());
            txtDescription.setText(subject.getDescription());
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Subject getSubject() {
        return subject;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (subject == null) {
                subject = new Subject();
            }

            subject.setSubjectCode(txtSubjectCode.getText());
            subject.setSubjectName(txtSubjectName.getText());
            subject.setDescription(txtDescription.getText());

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtSubjectCode.getText() == null || txtSubjectCode.getText().isEmpty()) {
            errorMessage += "Subject code is required!\n";
        }
        if (txtSubjectName.getText() == null || txtSubjectName.getText().isEmpty()) {
            errorMessage += "Subject name is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
