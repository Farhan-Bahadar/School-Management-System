package com.school.controllers;

import com.school.models.Student;
import com.school.services.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class StudentController implements Initializable {

    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, Integer> colId;
    @FXML private TableColumn<Student, String> colAdmission;
    @FXML private TableColumn<Student, String> colName;
    @FXML private TableColumn<Student, String> colGender;
    @FXML private TableColumn<Student, String> colParent;
    @FXML private TableColumn<Student, String> colClass;
    @FXML private TableColumn<Student, String> colStatus;
    
    @FXML private TextField searchField;

    private final StudentService studentService;
    private ObservableList<Student> studentList;

    public StudentController() {
        this.studentService = new StudentService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadStudents();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colAdmission.setCellValueFactory(new PropertyValueFactory<>("admissionNumber"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colParent.setCellValueFactory(new PropertyValueFactory<>("parentName"));
        colClass.setCellValueFactory(new PropertyValueFactory<>("className"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadStudents();
            } else {
                List<Student> filtered = studentService.searchStudents(newValue);
                studentList = FXCollections.observableArrayList(filtered);
                studentTable.setItems(studentList);
            }
        });
    }

    @FXML
    private void loadStudents() {
        List<Student> students = studentService.getAllStudents();
        studentList = FXCollections.observableArrayList(students);
        studentTable.setItems(studentList);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) {
        showStudentForm(null);
    }

    @FXML
    private void handleEditStudent(ActionEvent event) {
        Student selected = studentTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showStudentForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a student to edit.");
        }
    }

    private void showStudentForm(Student student) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/StudentForm.fxml"));
            Parent root = loader.load();

            StudentFormController controller = loader.getController();
            controller.setStudent(student);

            Stage stage = new Stage();
            stage.setTitle(student == null ? "Add New Student" : "Edit Student");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Student studentData = controller.getStudent();
                boolean success;
                if (student == null) {
                    Integer classId = controller.getSelectedClassId();
                    success = studentService.addStudent(studentData, classId);
                } else {
                    success = studentService.updateStudent(studentData);
                }

                if (success) {
                    loadStudents();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Student saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save student.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the student form.");
        }
    }

    @FXML
    private void handleDeleteStudent(ActionEvent event) {
        Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete student: " + selectedStudent.getFullName() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (studentService.deleteStudent(selectedStudent.getId())) {
                    loadStudents();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Student deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete student.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a student to delete.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
