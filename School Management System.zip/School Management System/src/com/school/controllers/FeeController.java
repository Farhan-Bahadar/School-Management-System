package com.school.controllers;

import com.school.models.Fee;
import com.school.services.FeeService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class FeeController implements Initializable {

    @FXML private TableView<Fee> feeTable;
    @FXML private TableColumn<Fee, Integer> colId;
    @FXML private TableColumn<Fee, String> colStudent;
    @FXML private TableColumn<Fee, String> colAdmission;
    @FXML private TableColumn<Fee, String> colType;
    @FXML private TableColumn<Fee, Double> colAmount;
    @FXML private TableColumn<Fee, String> colDueDate;
    @FXML private TableColumn<Fee, String> colStatus;
    
    @FXML private TextField searchField;

    private final FeeService feeService;
    private ObservableList<Fee> feeList;

    public FeeController() {
        this.feeService = new FeeService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadFees();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colStudent.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colAdmission.setCellValueFactory(new PropertyValueFactory<>("admissionNumber"));
        colType.setCellValueFactory(new PropertyValueFactory<>("feeType"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colDueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadFees();
            } else {
                List<Fee> filtered = feeService.searchFees(newValue);
                feeList = FXCollections.observableArrayList(filtered);
                feeTable.setItems(feeList);
            }
        });
    }

    @FXML
    private void loadFees() {
        List<Fee> fees = feeService.getAllFees();
        feeList = FXCollections.observableArrayList(fees);
        feeTable.setItems(feeList);
    }

    @FXML
    private void handleCollectFee(ActionEvent event) {
        showFeeForm(null);
    }

    @FXML
    private void handleEditFee(ActionEvent event) {
        Fee selected = feeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showFeeForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a fee record to edit.");
        }
    }

    @FXML
    private void handleDeleteFee(ActionEvent event) {
        Fee selected = feeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete this fee record?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (feeService.removeFee(selected.getId())) {
                    loadFees();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Fee record deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete fee record.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a fee record to delete.");
        }
    }

    private void showFeeForm(Fee fee) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/FeeForm.fxml"));
            Parent root = loader.load();

            FeeFormController controller = loader.getController();
            controller.setFee(fee);

            Stage stage = new Stage();
            stage.setTitle(fee == null ? "Collect Fee" : "Edit Fee Record");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Fee feeData = controller.getFee();
                boolean success;
                if (fee == null) {
                    success = feeService.createFeeRecord(feeData);
                } else {
                    success = feeService.updateFee(feeData);
                }

                if (success) {
                    loadFees();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Fee record saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save fee record.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the fee form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
