package com.school.controllers;

import com.school.models.Book;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class BookFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtTitle;
    @FXML private TextField txtAuthor;
    @FXML private TextField txtIsbn;
    @FXML private ComboBox<String> comboStatus;
    @FXML private Button btnSave;

    private Book book;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        comboStatus.setItems(FXCollections.observableArrayList("AVAILABLE", "BORROWED", "LOST", "REPAIR"));
        comboStatus.setValue("AVAILABLE");
    }

    public void setBook(Book book) {
        this.book = book;
        if (book != null) {
            lblTitle.setText("Edit Book");
            txtTitle.setText(book.getTitle());
            txtAuthor.setText(book.getAuthor());
            txtIsbn.setText(book.getIsbn());
            comboStatus.setValue(book.getStatus());
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Book getBook() {
        return book;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (book == null) {
                book = new Book();
                book.setAddedDate(LocalDate.now());
            }

            book.setTitle(txtTitle.getText());
            book.setAuthor(txtAuthor.getText());
            book.setIsbn(txtIsbn.getText());
            book.setStatus(comboStatus.getValue());

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtTitle.getText() == null || txtTitle.getText().isEmpty()) {
            errorMessage += "Title is required!\n";
        }
        if (txtAuthor.getText() == null || txtAuthor.getText().isEmpty()) {
            errorMessage += "Author is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
