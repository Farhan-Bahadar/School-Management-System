package com.school.controllers;

import com.school.models.Attendance;
import com.school.services.AttendanceService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AttendanceController implements Initializable {

    @FXML private TableView<Attendance> attendanceTable;
    @FXML private TableColumn<Attendance, Long> colId;
    @FXML private TableColumn<Attendance, String> colStudent;
    @FXML private TableColumn<Attendance, String> colAdmission;
    @FXML private TableColumn<Attendance, String> colClass;
    @FXML private TableColumn<Attendance, String> colDate;
    @FXML private TableColumn<Attendance, String> colStatus;
    @FXML private TableColumn<Attendance, String> colRemarks;

    private final AttendanceService attendanceService;
    private ObservableList<Attendance> attendanceList;

    public AttendanceController() {
        this.attendanceService = new AttendanceService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadAttendance();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colStudent.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colAdmission.setCellValueFactory(new PropertyValueFactory<>("admissionNumber"));
        colClass.setCellValueFactory(new PropertyValueFactory<>("className"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colRemarks.setCellValueFactory(new PropertyValueFactory<>("remarks"));
    }

    @FXML
    private void loadAttendance() {
        List<Attendance> records = attendanceService.getAllAttendance();
        attendanceList = FXCollections.observableArrayList(records);
        attendanceTable.setItems(attendanceList);
    }

    @FXML
    private void handleMarkAttendance(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/AttendanceDialog.fxml"));
            Parent root = loader.load();

            AttendanceDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.setTitle("Mark Attendance");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                loadAttendance();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Attendance recorded successfully.");
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the attendance form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
