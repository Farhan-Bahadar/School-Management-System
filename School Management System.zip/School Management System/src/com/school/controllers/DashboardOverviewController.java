package com.school.controllers;

import com.school.models.Attendance;
import com.school.services.AttendanceService;
import com.school.services.ClassService;
import com.school.services.FeeService;
import com.school.services.StudentService;
import com.school.services.TeacherService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class DashboardOverviewController implements Initializable {

    @FXML private Label lblTotalStudents;
    @FXML private Label lblTotalTeachers;
    @FXML private Label lblTotalClasses;
    @FXML private Label lblTotalRevenue;
    @FXML private Label lblAttendanceRate;

    private final StudentService studentService;
    private final TeacherService teacherService;
    private final ClassService classService;
    private final FeeService feeService;
    private final AttendanceService attendanceService;

    public DashboardOverviewController() {
        this.studentService = new StudentService();
        this.teacherService = new TeacherService();
        this.classService = new ClassService();
        this.feeService = new FeeService();
        this.attendanceService = new AttendanceService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        refreshStats();
    }

    private void refreshStats() {
        try {
            int students = studentService.getAllStudents().size();
            int teachers = teacherService.getAllTeachers().size();
            int classes = classService.getAllClasses().size();
            
            double revenue = feeService.getAllFees().stream()
                    .filter(f -> "PAID".equalsIgnoreCase(f.getStatus()))
                    .mapToDouble(f -> f.getAmount())
                    .sum();

            // Calculate today's attendance rate
            List<Attendance> todayAttendance = attendanceService.getAllAttendance().stream()
                    .filter(a -> a.getDate().equals(LocalDate.now()))
                    .toList();
            
            String attendanceRate = "0%";
            if (!todayAttendance.isEmpty()) {
                long present = todayAttendance.stream()
                        .filter(a -> "PRESENT".equalsIgnoreCase(a.getStatus()))
                        .count();
                double rate = (double) present / todayAttendance.size() * 100;
                attendanceRate = String.format("%.1f%%", rate);
            } else if (students > 0) {
                attendanceRate = "N/A"; // No records yet for today
            }

            lblTotalStudents.setText(String.valueOf(students));
            lblTotalTeachers.setText(String.valueOf(teachers));
            lblTotalClasses.setText(String.valueOf(classes));
            lblTotalRevenue.setText("$" + String.format("%.2f", revenue));
            lblAttendanceRate.setText(attendanceRate);
            
        } catch (Exception e) {
            e.printStackTrace();
            // Maintain placeholders if DB fails
        }
    }

    @FXML
    private void quickRegisterStudent(ActionEvent event) {
        if (DashboardController.getInstance() != null) {
            DashboardController.getInstance().showStudentManagement(null);
        }
    }

    @FXML
    private void quickMarkAttendance(ActionEvent event) {
        if (DashboardController.getInstance() != null) {
            DashboardController.getInstance().showAttendanceManagement(null);
        }
    }

    @FXML
    private void quickCollectFee(ActionEvent event) {
        if (DashboardController.getInstance() != null) {
            DashboardController.getInstance().showFeeManagement(null);
        }
    }

    @FXML
    private void quickAddExam(ActionEvent event) {
        if (DashboardController.getInstance() != null) {
            DashboardController.getInstance().showExamManagement(null);
        }
    }
}
