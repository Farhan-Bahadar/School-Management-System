package com.school.controllers;

import com.school.models.Fee;
import com.school.models.Student;
import com.school.services.StudentService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class FeeFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private ComboBox<Student> comboStudent;
    @FXML private ComboBox<String> comboFeeType;
    @FXML private TextField txtAmount;
    @FXML private DatePicker dateDue;
    @FXML private ComboBox<String> comboStatus;
    @FXML private VBox vboxPayment;
    @FXML private DatePicker datePayment;
    @FXML private TextField txtTransactionId;
    @FXML private Button btnSave;

    private Fee fee;
    private boolean saveClicked = false;
    private StudentService studentService;

    public FeeFormController() {
        this.studentService = new StudentService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadStudents();
        setupStudentComboBox();
        comboFeeType.setItems(FXCollections.observableArrayList("TUITION", "ADMISSION", "EXAM", "LIBRARY", "TRANSPORT", "OTHER"));
        comboStatus.setItems(FXCollections.observableArrayList("PENDING", "PAID", "PARTIAL", "OVERDUE"));
        
        comboStatus.setOnAction(e -> {
            boolean isPaid = "PAID".equals(comboStatus.getValue());
            vboxPayment.setDisable(!isPaid);
            if (isPaid && datePayment.getValue() == null) {
                datePayment.setValue(LocalDate.now());
            }
        });
        
        vboxPayment.setDisable(true);
    }

    private void loadStudents() {
        List<Student> students = studentService.getAllStudents();
        comboStudent.setItems(FXCollections.observableArrayList(students));
    }

    private void setupStudentComboBox() {
        comboStudent.setConverter(new StringConverter<Student>() {
            @Override
            public String toString(Student s) {
                return s == null ? "" : s.getFullName() + " (" + s.getAdmissionNumber() + ")";
            }

            @Override
            public Student fromString(String string) {
                return null;
            }
        });
    }

    public void setFee(Fee fee) {
        this.fee = fee;
        if (fee != null) {
            lblTitle.setText("Edit Fee Record");
            
            for (Student s : comboStudent.getItems()) {
                if (s.getId() == fee.getStudentId()) {
                    comboStudent.setValue(s);
                    break;
                }
            }
            
            comboFeeType.setValue(fee.getFeeType());
            txtAmount.setText(String.valueOf(fee.getAmount()));
            dateDue.setValue(fee.getDueDate());
            comboStatus.setValue(fee.getStatus());
            datePayment.setValue(fee.getPaymentDate());
            txtTransactionId.setText(fee.getTransactionId());
            
            vboxPayment.setDisable(!"PAID".equals(fee.getStatus()));
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Fee getFee() {
        return fee;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (fee == null) {
                fee = new Fee();
            }

            Student selectedStudent = comboStudent.getValue();
            fee.setStudentId(selectedStudent.getId());
            fee.setStudentName(selectedStudent.getFullName());
            fee.setAdmissionNumber(selectedStudent.getAdmissionNumber());
            
            fee.setFeeType(comboFeeType.getValue());
            fee.setAmount(Double.parseDouble(txtAmount.getText()));
            fee.setDueDate(dateDue.getValue());
            fee.setStatus(comboStatus.getValue());
            
            if ("PAID".equals(fee.getStatus())) {
                fee.setPaymentDate(datePayment.getValue());
                fee.setTransactionId(txtTransactionId.getText());
            } else {
                fee.setPaymentDate(null);
                fee.setTransactionId(null);
            }

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (comboStudent.getValue() == null) {
            errorMessage += "Student selection is required!\n";
        }
        if (comboFeeType.getValue() == null) {
            errorMessage += "Fee type is required!\n";
        }
        if (txtAmount.getText() == null || txtAmount.getText().isEmpty()) {
            errorMessage += "Amount is required!\n";
        } else {
            try {
                Double.parseDouble(txtAmount.getText());
            } catch (NumberFormatException e) {
                errorMessage += "Invalid amount format!\n";
            }
        }
        if (dateDue.getValue() == null) {
            errorMessage += "Due date is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
