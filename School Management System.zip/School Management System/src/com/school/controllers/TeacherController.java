package com.school.controllers;

import com.school.models.Teacher;
import com.school.services.TeacherService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class TeacherController implements Initializable {

    @FXML private TableView<Teacher> teacherTable;
    @FXML private TableColumn<Teacher, Integer> colId;
    @FXML private TableColumn<Teacher, String> colEmployeeId;
    @FXML private TableColumn<Teacher, String> colName;
    @FXML private TableColumn<Teacher, String> colDepartment;
    @FXML private TableColumn<Teacher, String> colContact;
    @FXML private TableColumn<Teacher, String> colEmail;
    @FXML private TableColumn<Teacher, String> colStatus;
    
    @FXML private TextField searchField;

    private final TeacherService teacherService;
    private ObservableList<Teacher> teacherList;

    public TeacherController() {
        this.teacherService = new TeacherService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadTeachers();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colEmployeeId.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colDepartment.setCellValueFactory(new PropertyValueFactory<>("qualification"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadTeachers();
            } else {
                List<Teacher> filtered = teacherService.searchTeachers(newValue);
                teacherList = FXCollections.observableArrayList(filtered);
                teacherTable.setItems(teacherList);
            }
        });
    }

    @FXML
    private void loadTeachers() {
        List<Teacher> teachers = teacherService.getAllTeachers();
        teacherList = FXCollections.observableArrayList(teachers);
        teacherTable.setItems(teacherList);
    }

    @FXML
    private void handleAddTeacher(ActionEvent event) {
        showTeacherForm(null);
    }

    @FXML
    private void handleEditTeacher(ActionEvent event) {
        Teacher selected = teacherTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showTeacherForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a teacher to edit.");
        }
    }

    private void showTeacherForm(Teacher teacher) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/TeacherForm.fxml"));
            Parent root = loader.load();

            TeacherFormController controller = loader.getController();
            controller.setTeacher(teacher);

            Stage stage = new Stage();
            stage.setTitle(teacher == null ? "Add New Teacher" : "Edit Teacher");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Teacher teacherData = controller.getTeacher();
                boolean success;
                if (teacher == null) {
                    success = teacherService.registerTeacher(teacherData);
                } else {
                    success = teacherService.updateTeacher(teacherData);
                }

                if (success) {
                    loadTeachers();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save teacher.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the teacher form.");
        }
    }

    @FXML
    private void handleDeleteTeacher(ActionEvent event) {
        Teacher selectedTeacher = teacherTable.getSelectionModel().getSelectedItem();
        if (selectedTeacher != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete teacher: " + selectedTeacher.getFullName() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (teacherService.removeTeacher(selectedTeacher.getId())) {
                    loadTeachers();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete teacher.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a teacher to delete.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
