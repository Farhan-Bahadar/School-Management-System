package com.school.controllers;

import com.school.models.ClassModel;
import com.school.models.Teacher;
import com.school.services.TeacherService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ClassFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtClassName;
    @FXML private TextField txtSection;
    @FXML private TextField txtRoomNumber;
    @FXML private ComboBox<Teacher> comboTeacher;
    @FXML private Button btnSave;

    private ClassModel classModel;
    private boolean saveClicked = false;
    private TeacherService teacherService;

    public ClassFormController() {
        this.teacherService = new TeacherService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadTeachers();
        setupTeacherComboBox();
    }

    private void loadTeachers() {
        List<Teacher> teachers = teacherService.getAllTeachers();
        comboTeacher.setItems(FXCollections.observableArrayList(teachers));
    }

    private void setupTeacherComboBox() {
        comboTeacher.setConverter(new StringConverter<Teacher>() {
            @Override
            public String toString(Teacher teacher) {
                return teacher == null ? "None" : teacher.getFullName();
            }

            @Override
            public Teacher fromString(String string) {
                return null;
            }
        });
    }

    public void setClassModel(ClassModel classModel) {
        this.classModel = classModel;
        if (classModel != null) {
            lblTitle.setText("Edit Class");
            txtClassName.setText(classModel.getClassName());
            txtSection.setText(classModel.getSection());
            txtRoomNumber.setText(classModel.getRoomNumber());
            
            if (classModel.getTeacherId() != null) {
                for (Teacher t : comboTeacher.getItems()) {
                    if (t.getId() == classModel.getTeacherId()) {
                        comboTeacher.setValue(t);
                        break;
                    }
                }
            }
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public ClassModel getClassModel() {
        return classModel;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (classModel == null) {
                classModel = new ClassModel();
            }

            classModel.setClassName(txtClassName.getText());
            classModel.setSection(txtSection.getText());
            classModel.setRoomNumber(txtRoomNumber.getText());
            
            Teacher selectedTeacher = comboTeacher.getValue();
            if (selectedTeacher != null) {
                classModel.setTeacherId(selectedTeacher.getId());
                classModel.setTeacherName(selectedTeacher.getFullName());
            } else {
                classModel.setTeacherId(null);
                classModel.setTeacherName(null);
            }

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtClassName.getText() == null || txtClassName.getText().isEmpty()) {
            errorMessage += "Class name is required!\n";
        }
        if (txtSection.getText() == null || txtSection.getText().isEmpty()) {
            errorMessage += "Section is required!\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
