package com.school.controllers;

import com.school.models.Exam;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class ExamFormController implements Initializable {

    @FXML private Label lblTitle;
    @FXML private TextField txtExamName;
    @FXML private DatePicker dateStart;
    @FXML private DatePicker dateEnd;
    @FXML private Button btnSave;

    private Exam exam;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    public void setExam(Exam exam) {
        this.exam = exam;
        if (exam != null) {
            lblTitle.setText("Edit Exam");
            txtExamName.setText(exam.getExamName());
            dateStart.setValue(exam.getStartDate());
            dateEnd.setValue(exam.getEndDate());
        }
    }

    public boolean isSaveClicked() {
        return saveClicked;
    }

    public Exam getExam() {
        return exam;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (isInputValid()) {
            if (exam == null) {
                exam = new Exam();
            }

            exam.setExamName(txtExamName.getText());
            exam.setStartDate(dateStart.getValue());
            exam.setEndDate(dateEnd.getValue());

            saveClicked = true;
            closeStage();
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private void closeStage() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (txtExamName.getText() == null || txtExamName.getText().isEmpty()) {
            errorMessage += "Exam name is required!\n";
        }
        if (dateStart.getValue() == null) {
            errorMessage += "Start date is required!\n";
        }
        if (dateEnd.getValue() == null) {
            errorMessage += "End date is required!\n";
        }
        if (dateStart.getValue() != null && dateEnd.getValue() != null) {
            if (dateEnd.getValue().isBefore(dateStart.getValue())) {
                errorMessage += "End date cannot be before start date!\n";
            }
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText("Please correct the following errors:");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
