package com.school.controllers;

import com.school.models.Book;
import com.school.services.LibraryService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class LibraryController implements Initializable {

    @FXML private TableView<Book> bookTable;
    @FXML private TableColumn<Book, Integer> colId;
    @FXML private TableColumn<Book, String> colTitle;
    @FXML private TableColumn<Book, String> colAuthor;
    @FXML private TableColumn<Book, String> colIsbn;
    @FXML private TableColumn<Book, String> colStatus;
    @FXML private TableColumn<Book, String> colAddedDate;
    
    @FXML private TextField searchField;

    private final LibraryService libraryService;
    private ObservableList<Book> bookList;

    public LibraryController() {
        this.libraryService = new LibraryService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadBooks();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        colIsbn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colAddedDate.setCellValueFactory(new PropertyValueFactory<>("addedDate"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadBooks();
            } else {
                List<Book> filtered = libraryService.searchBooks(newValue);
                bookList = FXCollections.observableArrayList(filtered);
                bookTable.setItems(bookList);
            }
        });
    }

    @FXML
    private void loadBooks() {
        List<Book> books = libraryService.getAllBooks();
        bookList = FXCollections.observableArrayList(books);
        bookTable.setItems(bookList);
    }

    @FXML
    private void handleAddBook(ActionEvent event) {
        showBookForm(null);
    }

    @FXML
    private void handleEditBook(ActionEvent event) {
        Book selected = bookTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showBookForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a book to edit.");
        }
    }

    @FXML
    private void handleDeleteBook(ActionEvent event) {
        Book selected = bookTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete book: " + selected.getTitle() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (libraryService.removeBook(selected.getId())) {
                    loadBooks();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Book deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete book.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a book to delete.");
        }
    }

    private void showBookForm(Book book) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/BookForm.fxml"));
            Parent root = loader.load();

            BookFormController controller = loader.getController();
            controller.setBook(book);

            Stage stage = new Stage();
            stage.setTitle(book == null ? "Add New Book" : "Edit Book");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Book bookData = controller.getBook();
                boolean success;
                if (book == null) {
                    success = libraryService.createBook(bookData);
                } else {
                    success = libraryService.updateBook(bookData);
                }

                if (success) {
                    loadBooks();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Book saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save book.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the book form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
