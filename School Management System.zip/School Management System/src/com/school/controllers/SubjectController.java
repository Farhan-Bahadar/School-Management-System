package com.school.controllers;

import com.school.models.Subject;
import com.school.services.SubjectService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SubjectController implements Initializable {

    @FXML private TableView<Subject> subjectTable;
    @FXML private TableColumn<Subject, Integer> colId;
    @FXML private TableColumn<Subject, String> colSubjectCode;
    @FXML private TableColumn<Subject, String> colSubjectName;
    @FXML private TableColumn<Subject, String> colDescription;
    
    @FXML private TextField searchField;

    private final SubjectService subjectService;
    private ObservableList<Subject> subjectList;

    public SubjectController() {
        this.subjectService = new SubjectService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadSubjects();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colSubjectCode.setCellValueFactory(new PropertyValueFactory<>("subjectCode"));
        colSubjectName.setCellValueFactory(new PropertyValueFactory<>("subjectName"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadSubjects();
            } else {
                List<Subject> filtered = subjectService.searchSubjects(newValue);
                subjectList = FXCollections.observableArrayList(filtered);
                subjectTable.setItems(subjectList);
            }
        });
    }

    @FXML
    private void loadSubjects() {
        List<Subject> subjects = subjectService.getAllSubjects();
        subjectList = FXCollections.observableArrayList(subjects);
        subjectTable.setItems(subjectList);
    }

    @FXML
    private void handleAddSubject(ActionEvent event) {
        showSubjectForm(null);
    }

    @FXML
    private void handleEditSubject(ActionEvent event) {
        Subject selected = subjectTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showSubjectForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a subject to edit.");
        }
    }

    @FXML
    private void handleDeleteSubject(ActionEvent event) {
        Subject selected = subjectTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete subject: " + selected.getSubjectName() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (subjectService.removeSubject(selected.getId())) {
                    loadSubjects();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Subject deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete subject.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a subject to delete.");
        }
    }

    private void showSubjectForm(Subject subject) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/SubjectForm.fxml"));
            Parent root = loader.load();

            SubjectFormController controller = loader.getController();
            controller.setSubject(subject);

            Stage stage = new Stage();
            stage.setTitle(subject == null ? "Add New Subject" : "Edit Subject");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                Subject subjectData = controller.getSubject();
                boolean success;
                if (subject == null) {
                    success = subjectService.addSubject(subjectData);
                } else {
                    success = subjectService.updateSubject(subjectData);
                }

                if (success) {
                    loadSubjects();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Subject saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save subject.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the subject form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
