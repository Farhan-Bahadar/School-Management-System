package com.school.controllers;

import com.school.models.ClassModel;
import com.school.services.ClassService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ClassController implements Initializable {

    @FXML private TableView<ClassModel> classTable;
    @FXML private TableColumn<ClassModel, Integer> colId;
    @FXML private TableColumn<ClassModel, String> colClassName;
    @FXML private TableColumn<ClassModel, String> colSection;
    @FXML private TableColumn<ClassModel, String> colRoom;
    @FXML private TableColumn<ClassModel, String> colTeacher;
    
    @FXML private TextField searchField;

    private final ClassService classService;
    private ObservableList<ClassModel> classList;

    public ClassController() {
        this.classService = new ClassService();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupTableColumns();
        loadClasses();
        setupSearch();
    }

    private void setupTableColumns() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colClassName.setCellValueFactory(new PropertyValueFactory<>("className"));
        colSection.setCellValueFactory(new PropertyValueFactory<>("section"));
        colRoom.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        colTeacher.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
    }

    private void setupSearch() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.trim().isEmpty()) {
                loadClasses();
            } else {
                List<ClassModel> filtered = classService.searchClasses(newValue);
                classList = FXCollections.observableArrayList(filtered);
                classTable.setItems(classList);
            }
        });
    }

    @FXML
    private void loadClasses() {
        List<ClassModel> classes = classService.getAllClasses();
        classList = FXCollections.observableArrayList(classes);
        classTable.setItems(classList);
    }

    @FXML
    private void handleAddClass(ActionEvent event) {
        showClassForm(null);
    }

    @FXML
    private void handleEditClass(ActionEvent event) {
        ClassModel selected = classTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showClassForm(selected);
        } else {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a class to edit.");
        }
    }

    @FXML
    private void handleDeleteClass(ActionEvent event) {
        ClassModel selected = classTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Delete");
            confirm.setHeaderText(null);
            confirm.setContentText("Are you sure you want to delete class: " + selected.getFullClassName() + "?");
            
            if (confirm.showAndWait().get() == ButtonType.OK) {
                if (classService.removeClass(selected.getId())) {
                    loadClasses();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Class deleted successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete class.");
                }
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a class to delete.");
        }
    }

    private void showClassForm(ClassModel classModel) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/resources/fxml/ClassForm.fxml"));
            Parent root = loader.load();

            ClassFormController controller = loader.getController();
            controller.setClassModel(classModel);

            Stage stage = new Stage();
            stage.setTitle(classModel == null ? "Add New Class" : "Edit Class");
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaveClicked()) {
                ClassModel classData = controller.getClassModel();
                boolean success;
                if (classModel == null) {
                    success = classService.addClass(classData);
                } else {
                    success = classService.updateClass(classData);
                }

                if (success) {
                    loadClasses();
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Class saved successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to save class.");
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "System Error", "Could not load the class form.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
