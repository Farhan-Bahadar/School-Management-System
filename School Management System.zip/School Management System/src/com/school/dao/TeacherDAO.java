package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.Teacher;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAO {

    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        String query = "SELECT * FROM teachers";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                teachers.add(mapResultSetToTeacher(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }

    public boolean addTeacher(Teacher teacher) {
        String query = "INSERT INTO teachers (employee_id, first_name, last_name, gender, date_of_birth, " +
                "contact_number, email, address, qualification, hire_date, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, teacher.getEmployeeId());
            stmt.setString(2, teacher.getFirstName());
            stmt.setString(3, teacher.getLastName());
            stmt.setString(4, teacher.getGender());
            stmt.setDate(5, Date.valueOf(teacher.getDateOfBirth()));
            stmt.setString(6, teacher.getContactNumber());
            stmt.setString(7, teacher.getEmail());
            stmt.setString(8, teacher.getAddress());
            stmt.setString(9, teacher.getQualification());
            stmt.setDate(10, Date.valueOf(teacher.getHireDate()));
            stmt.setString(11, teacher.getStatus() != null ? teacher.getStatus() : "ACTIVE");

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteTeacher(int teacherId) {
        String query = "DELETE FROM teachers WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, teacherId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateTeacher(Teacher teacher) {
        String query = "UPDATE teachers SET employee_id=?, first_name=?, last_name=?, gender=?, date_of_birth=?, " +
                "contact_number=?, email=?, address=?, qualification=?, hire_date=?, status=? " +
                "WHERE id=?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, teacher.getEmployeeId());
            stmt.setString(2, teacher.getFirstName());
            stmt.setString(3, teacher.getLastName());
            stmt.setString(4, teacher.getGender());
            stmt.setDate(5, Date.valueOf(teacher.getDateOfBirth()));
            stmt.setString(6, teacher.getContactNumber());
            stmt.setString(7, teacher.getEmail());
            stmt.setString(8, teacher.getAddress());
            stmt.setString(9, teacher.getQualification());
            stmt.setDate(10, Date.valueOf(teacher.getHireDate()));
            stmt.setString(11, teacher.getStatus());
            stmt.setInt(12, teacher.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Teacher> searchTeachers(String keyword) {
        List<Teacher> teachers = new ArrayList<>();
        String query = "SELECT * FROM teachers WHERE employee_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR qualification LIKE ?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    teachers.add(mapResultSetToTeacher(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }

    private Teacher mapResultSetToTeacher(ResultSet rs) throws SQLException {
        Teacher teacher = new Teacher();
        teacher.setId(rs.getInt("id"));
        teacher.setEmployeeId(rs.getString("employee_id"));
        teacher.setFirstName(rs.getString("first_name"));
        teacher.setLastName(rs.getString("last_name"));
        teacher.setGender(rs.getString("gender"));
        teacher.setDateOfBirth(rs.getDate("date_of_birth").toLocalDate());
        teacher.setContactNumber(rs.getString("contact_number"));
        teacher.setEmail(rs.getString("email"));
        teacher.setAddress(rs.getString("address"));
        teacher.setQualification(rs.getString("qualification"));
        teacher.setHireDate(rs.getDate("hire_date").toLocalDate());
        teacher.setStatus(rs.getString("status"));
        return teacher;
    }
}
