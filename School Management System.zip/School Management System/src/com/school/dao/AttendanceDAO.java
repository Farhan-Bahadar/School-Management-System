package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.Attendance;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {

    public List<Attendance> getAllAttendance() {
        List<Attendance> records = new ArrayList<>();
        // JOIN to get student name/admission and class name
        String query = "SELECT a.*, s.first_name, s.last_name, s.admission_number, c.class_name, c.section " +
                       "FROM attendance a " +
                       "JOIN students s ON a.student_id = s.id " +
                       "JOIN classes c ON a.class_id = c.id " +
                       "ORDER BY a.date DESC, c.class_name, s.first_name";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Attendance att = new Attendance();
                att.setId(rs.getLong("id"));
                att.setStudentId(rs.getInt("student_id"));
                att.setClassId(rs.getInt("class_id"));
                att.setDate(rs.getDate("date").toLocalDate());
                att.setStatus(rs.getString("status"));
                att.setRemarks(rs.getString("remarks"));
                
                // Populated from JOINs
                att.setStudentName(rs.getString("first_name") + " " + rs.getString("last_name"));
                att.setAdmissionNumber(rs.getString("admission_number"));
                att.setClassName(rs.getString("class_name") + " - " + rs.getString("section"));

                records.add(att);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    public boolean addAttendance(Attendance att) {
        String query = "INSERT INTO attendance (student_id, class_id, date, status, remarks) VALUES (?, ?, ?, ?, ?) " +
                       "ON DUPLICATE KEY UPDATE status = ?, remarks = ?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, att.getStudentId());
            stmt.setInt(2, att.getClassId());
            stmt.setDate(3, Date.valueOf(att.getDate()));
            stmt.setString(4, att.getStatus());
            stmt.setString(5, att.getRemarks());
            
            // For ON DUPLICATE KEY UPDATE (in case they want to update an existing record for that day)
            stmt.setString(6, att.getStatus());
            stmt.setString(7, att.getRemarks());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Attendance> getAttendanceByDateAndClass(java.time.LocalDate date, int classId) {
        List<Attendance> records = new ArrayList<>();
        String query = "SELECT a.*, s.first_name, s.last_name, s.admission_number, c.class_name, c.section " +
                       "FROM attendance a " +
                       "JOIN students s ON a.student_id = s.id " +
                       "JOIN classes c ON a.class_id = c.id " +
                       "WHERE a.date = ? AND a.class_id = ? " +
                       "ORDER BY s.first_name";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDate(1, Date.valueOf(date));
            stmt.setInt(2, classId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Attendance att = new Attendance();
                    att.setId(rs.getLong("id"));
                    att.setStudentId(rs.getInt("student_id"));
                    att.setClassId(rs.getInt("class_id"));
                    att.setDate(rs.getDate("date").toLocalDate());
                    att.setStatus(rs.getString("status"));
                    att.setRemarks(rs.getString("remarks"));
                    
                    att.setStudentName(rs.getString("first_name") + " " + rs.getString("last_name"));
                    att.setAdmissionNumber(rs.getString("admission_number"));
                    att.setClassName(rs.getString("class_name") + " - " + rs.getString("section"));

                    records.add(att);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }
}
