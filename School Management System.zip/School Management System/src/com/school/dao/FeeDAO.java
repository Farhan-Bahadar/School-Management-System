package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.Fee;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FeeDAO {

    public List<Fee> getAllFees() {
        List<Fee> fees = new ArrayList<>();
        // JOIN with students table to get admission_number and full name
        String query = "SELECT f.*, s.admission_number, s.first_name, s.last_name " +
                       "FROM fees f " +
                       "JOIN students s ON f.student_id = s.id " +
                       "ORDER BY f.due_date DESC";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Fee fee = new Fee();
                fee.setId(rs.getInt("id"));
                fee.setStudentId(rs.getInt("student_id"));
                fee.setFeeType(rs.getString("fee_type"));
                fee.setAmount(rs.getDouble("amount"));
                fee.setDueDate(rs.getDate("due_date").toLocalDate());
                fee.setStatus(rs.getString("status"));
                
                if (rs.getDate("payment_date") != null) {
                    fee.setPaymentDate(rs.getDate("payment_date").toLocalDate());
                }
                fee.setTransactionId(rs.getString("transaction_id"));

                // Populated from JOIN
                fee.setAdmissionNumber(rs.getString("admission_number"));
                fee.setStudentName(rs.getString("first_name") + " " + rs.getString("last_name"));

                fees.add(fee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fees;
    }

    public boolean addFee(Fee fee) {
        String query = "INSERT INTO fees (student_id, fee_type, amount, due_date, status) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, fee.getStudentId());
            stmt.setString(2, fee.getFeeType());
            stmt.setDouble(3, fee.getAmount());
            stmt.setDate(4, Date.valueOf(fee.getDueDate()));
            stmt.setString(5, fee.getStatus() != null ? fee.getStatus() : "UNPAID");

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFee(Fee fee) {
        String query = "UPDATE fees SET student_id=?, fee_type=?, amount=?, due_date=?, status=?, payment_date=?, transaction_id=? WHERE id=?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, fee.getStudentId());
            stmt.setString(2, fee.getFeeType());
            stmt.setDouble(3, fee.getAmount());
            stmt.setDate(4, Date.valueOf(fee.getDueDate()));
            stmt.setString(5, fee.getStatus());
            
            if (fee.getPaymentDate() != null) {
                stmt.setDate(6, Date.valueOf(fee.getPaymentDate()));
            } else {
                stmt.setNull(6, Types.DATE);
            }
            
            stmt.setString(7, fee.getTransactionId());
            stmt.setInt(8, fee.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Fee> searchFees(String keyword) {
        List<Fee> fees = new ArrayList<>();
        String query = "SELECT f.*, s.admission_number, s.first_name, s.last_name " +
                       "FROM fees f " +
                       "JOIN students s ON f.student_id = s.id " +
                       "WHERE s.admission_number LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR f.fee_type LIKE ? " +
                       "ORDER BY f.due_date DESC";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Fee fee = new Fee();
                    fee.setId(rs.getInt("id"));
                    fee.setStudentId(rs.getInt("student_id"));
                    fee.setFeeType(rs.getString("fee_type"));
                    fee.setAmount(rs.getDouble("amount"));
                    fee.setDueDate(rs.getDate("due_date").toLocalDate());
                    fee.setStatus(rs.getString("status"));
                    
                    if (rs.getDate("payment_date") != null) {
                        fee.setPaymentDate(rs.getDate("payment_date").toLocalDate());
                    }
                    fee.setTransactionId(rs.getString("transaction_id"));
                    fee.setAdmissionNumber(rs.getString("admission_number"));
                    fee.setStudentName(rs.getString("first_name") + " " + rs.getString("last_name"));
                    fees.add(fee);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fees;
    }

    public boolean deleteFee(int feeId) {
        String query = "DELETE FROM fees WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, feeId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
