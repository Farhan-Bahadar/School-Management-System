package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.Exam;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExamDAO {

    public List<Exam> getAllExams() {
        List<Exam> exams = new ArrayList<>();
        String query = "SELECT * FROM exams ORDER BY start_date DESC";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Exam exam = new Exam();
                exam.setId(rs.getInt("id"));
                exam.setExamName(rs.getString("exam_name"));
                exam.setStartDate(rs.getDate("start_date").toLocalDate());
                exam.setEndDate(rs.getDate("end_date").toLocalDate());
                exams.add(exam);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exams;
    }

    public boolean addExam(Exam exam) {
        String query = "INSERT INTO exams (exam_name, start_date, end_date) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, exam.getExamName());
            stmt.setDate(2, Date.valueOf(exam.getStartDate()));
            stmt.setDate(3, Date.valueOf(exam.getEndDate()));

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateExam(Exam exam) {
        String query = "UPDATE exams SET exam_name=?, start_date=?, end_date=? WHERE id=?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, exam.getExamName());
            stmt.setDate(2, Date.valueOf(exam.getStartDate()));
            stmt.setDate(3, Date.valueOf(exam.getEndDate()));
            stmt.setInt(4, exam.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Exam> searchExams(String keyword) {
        List<Exam> exams = new ArrayList<>();
        String query = "SELECT * FROM exams WHERE exam_name LIKE ? ORDER BY start_date DESC";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Exam exam = new Exam();
                    exam.setId(rs.getInt("id"));
                    exam.setExamName(rs.getString("exam_name"));
                    exam.setStartDate(rs.getDate("start_date").toLocalDate());
                    exam.setEndDate(rs.getDate("end_date").toLocalDate());
                    exams.add(exam);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exams;
    }

    public boolean deleteExam(int examId) {
        String query = "DELETE FROM exams WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, examId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
