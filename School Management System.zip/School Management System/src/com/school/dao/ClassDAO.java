package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.ClassModel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClassDAO {

    public List<ClassModel> getAllClasses() {
        List<ClassModel> classes = new ArrayList<>();
        // JOIN with teachers table to get the class teacher's full name
        String query = "SELECT c.*, t.first_name, t.last_name " +
                       "FROM classes c " +
                       "LEFT JOIN teachers t ON c.teacher_id = t.id " +
                       "ORDER BY c.class_name, c.section";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                ClassModel cls = new ClassModel();
                cls.setId(rs.getInt("id"));
                cls.setClassName(rs.getString("class_name"));
                cls.setSection(rs.getString("section"));
                cls.setRoomNumber(rs.getString("room_number"));
                
                int teacherId = rs.getInt("teacher_id");
                if (!rs.wasNull()) {
                    cls.setTeacherId(teacherId);
                    cls.setTeacherName(rs.getString("first_name") + " " + rs.getString("last_name"));
                } else {
                    cls.setTeacherName("Not Assigned");
                }

                classes.add(cls);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classes;
    }

    public boolean addClass(ClassModel classModel) {
        String query = "INSERT INTO classes (class_name, section, room_number, teacher_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, classModel.getClassName());
            stmt.setString(2, classModel.getSection());
            stmt.setString(3, classModel.getRoomNumber());
            
            if (classModel.getTeacherId() != null) {
                stmt.setInt(4, classModel.getTeacherId());
            } else {
                stmt.setNull(4, Types.INTEGER);
            }

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateClass(ClassModel classModel) {
        String query = "UPDATE classes SET class_name=?, section=?, room_number=?, teacher_id=? WHERE id=?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, classModel.getClassName());
            stmt.setString(2, classModel.getSection());
            stmt.setString(3, classModel.getRoomNumber());
            
            if (classModel.getTeacherId() != null) {
                stmt.setInt(4, classModel.getTeacherId());
            } else {
                stmt.setNull(4, Types.INTEGER);
            }
            stmt.setInt(5, classModel.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<ClassModel> searchClasses(String keyword) {
        List<ClassModel> classes = new ArrayList<>();
        String query = "SELECT c.*, t.first_name, t.last_name " +
                       "FROM classes c " +
                       "LEFT JOIN teachers t ON c.teacher_id = t.id " +
                       "WHERE c.class_name LIKE ? OR c.section LIKE ? OR c.room_number LIKE ? " +
                       "ORDER BY c.class_name, c.section";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ClassModel cls = new ClassModel();
                    cls.setId(rs.getInt("id"));
                    cls.setClassName(rs.getString("class_name"));
                    cls.setSection(rs.getString("section"));
                    cls.setRoomNumber(rs.getString("room_number"));
                    
                    int teacherId = rs.getInt("teacher_id");
                    if (!rs.wasNull()) {
                        cls.setTeacherId(teacherId);
                        cls.setTeacherName(rs.getString("first_name") + " " + rs.getString("last_name"));
                    } else {
                        cls.setTeacherName("Not Assigned");
                    }
                    classes.add(cls);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classes;
    }

    public boolean deleteClass(int classId) {
        String query = "DELETE FROM classes WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, classId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
