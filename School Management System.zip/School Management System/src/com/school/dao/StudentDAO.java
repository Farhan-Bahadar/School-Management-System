package com.school.dao;

import com.school.database.DatabaseConnection;
import com.school.models.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String query = "SELECT s.*, c.class_name, c.section FROM students s " +
                       "LEFT JOIN student_classes sc ON s.id = sc.student_id " +
                       "LEFT JOIN classes c ON sc.class_id = c.id";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                students.add(mapResultSetToStudent(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public int addStudent(Student student) {
        String query = "INSERT INTO students (admission_number, first_name, last_name, gender, date_of_birth, " +
                "blood_group, address, city, state, zip_code, parent_name, parent_contact, parent_email, enrollment_date, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, student.getAdmissionNumber());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.setString(4, student.getGender());
            stmt.setDate(5, Date.valueOf(student.getDateOfBirth()));
            stmt.setString(6, student.getBloodGroup());
            stmt.setString(7, student.getAddress());
            stmt.setString(8, student.getCity());
            stmt.setString(9, student.getState());
            stmt.setString(10, student.getZipCode());
            stmt.setString(11, student.getParentName());
            stmt.setString(12, student.getParentContact());
            stmt.setString(13, student.getParentEmail());
            stmt.setDate(14, Date.valueOf(student.getEnrollmentDate()));
            stmt.setString(15, student.getStatus() != null ? student.getStatus() : "ACTIVE");

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    public boolean deleteStudent(int studentId) {
        String query = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, studentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateStudent(Student student) {
        String query = "UPDATE students SET admission_number=?, first_name=?, last_name=?, gender=?, date_of_birth=?, " +
                "blood_group=?, address=?, city=?, state=?, zip_code=?, parent_name=?, parent_contact=?, parent_email=?, status=? " +
                "WHERE id=?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, student.getAdmissionNumber());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.setString(4, student.getGender());
            stmt.setDate(5, Date.valueOf(student.getDateOfBirth()));
            stmt.setString(6, student.getBloodGroup());
            stmt.setString(7, student.getAddress());
            stmt.setString(8, student.getCity());
            stmt.setString(9, student.getState());
            stmt.setString(10, student.getZipCode());
            stmt.setString(11, student.getParentName());
            stmt.setString(12, student.getParentContact());
            stmt.setString(13, student.getParentEmail());
            stmt.setString(14, student.getStatus());
            stmt.setInt(15, student.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Student> searchStudents(String keyword) {
        List<Student> students = new ArrayList<>();
        String query = "SELECT s.*, c.class_name, c.section FROM students s " +
                       "LEFT JOIN student_classes sc ON s.id = sc.student_id " +
                       "LEFT JOIN classes c ON sc.class_id = c.id " +
                       "WHERE s.admission_number LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.parent_name LIKE ?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            String searchPattern = "%" + keyword + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    students.add(mapResultSetToStudent(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public List<Student> getStudentsByClass(int classId) {
        List<Student> students = new ArrayList<>();
        String query = "SELECT s.*, c.class_name, c.section FROM students s " +
                       "JOIN student_classes sc ON s.id = sc.student_id " +
                       "JOIN classes c ON sc.class_id = c.id " +
                       "WHERE sc.class_id = ? AND s.status = 'ACTIVE'";

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, classId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    students.add(mapResultSetToStudent(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public boolean enrollStudent(int studentId, int classId, String academicYear) {
        String query = "INSERT INTO student_classes (student_id, class_id, academic_year) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, studentId);
            stmt.setInt(2, classId);
            stmt.setString(3, academicYear);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Student mapResultSetToStudent(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setId(rs.getInt("id"));
        student.setAdmissionNumber(rs.getString("admission_number"));
        student.setFirstName(rs.getString("first_name"));
        student.setLastName(rs.getString("last_name"));
        student.setGender(rs.getString("gender"));
        student.setDateOfBirth(rs.getDate("date_of_birth").toLocalDate());
        student.setBloodGroup(rs.getString("blood_group"));
        student.setAddress(rs.getString("address"));
        student.setCity(rs.getString("city"));
        student.setState(rs.getString("state"));
        student.setZipCode(rs.getString("zip_code"));
        student.setParentName(rs.getString("parent_name"));
        student.setParentContact(rs.getString("parent_contact"));
        student.setParentEmail(rs.getString("parent_email"));
        student.setEnrollmentDate(rs.getDate("enrollment_date").toLocalDate());
        student.setStatus(rs.getString("status"));
        
        String className = rs.getString("class_name");
        if (className != null) {
            student.setClassName(className + " - " + rs.getString("section"));
        } else {
            student.setClassName("Not Assigned");
        }
        
        return student;
    }
}
